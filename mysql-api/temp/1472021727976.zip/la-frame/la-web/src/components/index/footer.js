var Vue = require('vue');

module.exports = Vue.extend({
    template: __inline('/src/components/index/footer.html')
});
